package gameset;

public class console {
    
    public console(){}

    public void OutString (String instr){
        System.out.println(instr);
    }
}
