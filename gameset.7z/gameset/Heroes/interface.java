package gameset.Heroes;

interface  SetGamesDef {
    void step();
    String GetInfo();
    
}
 interface SetMagic{
    // int mannT = extracted();

    // static int extracted() {
    //     return 50;
    // }

 }
